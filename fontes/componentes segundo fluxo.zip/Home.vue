<template>
    <div>
      <Navbar />
      <h1>Home</h1>
      <router-view />
    </div>
  </template>
  
  <script>
  import Navbar from './Navbar.vue';
  
  export default {
    components: {
      Navbar,
    },
  };
  </script>
  