<template>
    <div>
      <h2>All Programs</h2>
      <router-view />
    </div>
  </template>
  
  <script>
  export default {
    name: 'AllPrograms',
  };
  </script>
  