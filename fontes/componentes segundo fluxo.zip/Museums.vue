<template>
    <div>
      <h3>Museums</h3>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Museums',
  };
  </script>
  