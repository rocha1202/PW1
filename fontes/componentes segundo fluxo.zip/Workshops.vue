<template>
    <div>
      <h3>Workshops</h3>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Workshops',
  };
  </script>
  