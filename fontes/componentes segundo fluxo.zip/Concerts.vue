<template>
    <div>
      <h3>Concerts</h3>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Concerts',
  };
  </script>
  