<template>
    <nav>
      <h3>Navbar</h3>
      <!-- Links de navegação podem ser adicionados aqui -->
    </nav>
  </template>
  
  <script>
  export default {
    name: 'Navbar',
  };
  </script>
  