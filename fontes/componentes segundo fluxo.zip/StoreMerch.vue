<template>
    <div>
      <h3>Merchandise</h3>
    </div>
  </template>
  
  <script>
  export default {
    name: 'StoreMerch',
  };
  </script>
  