<template>
    <div>
      <h3>Info Tickets</h3>
    </div>
  </template>
  
  <script>
  export default {
    name: 'InfoTickets',
  };
  </script>
  