<template>
    <div>
      <h3>Theater</h3>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Theater',
  };
  </script>
  